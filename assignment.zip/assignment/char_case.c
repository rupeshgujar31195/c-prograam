#include<stdio.h>
char DisplayConvert(char cValue)
{
    char ch = cValue;
    if(cValue>='A' && cValue<='Z')
    {
        
        printf("uppercase to lowercase %c",tolower(ch));
        
    }
    else if(cValue>='a' && cValue<='z')
    {
         
        printf("lowercase to uppercase %c",toupper(ch));

    }

}
int main()
{
    char cValue ='\0';
    printf("Enter Character\n");
    scanf("%c",&cValue);

    DisplayConvert(cValue);
    return 0;

}
