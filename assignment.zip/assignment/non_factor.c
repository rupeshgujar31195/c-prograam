//accept number from user and display its non factor

#include<stdio.h>
void NonFact(int iNo)
{
    int iCnt=0;
    iCnt=1;
    while(iCnt<iNo)
    {
        if((iNo%iCnt)!=0)
        {
            printf("%d\n",iCnt);
        }
     iCnt++;
     }
}
int main()
{
    int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

    NonFact(iValue);
    return 0;

}