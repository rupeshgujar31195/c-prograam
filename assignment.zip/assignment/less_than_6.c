//accept number from user and count frequency of such a digit which are less than 6

#include<stdio.h>
int Count(int iNo)
{
    int iDigit=0,iCnt=0,i=0;
iCnt=1;
    while(iNo!=0)
    {
        iDigit=iNo%10;
        if(iDigit<6)
        {
            i=iCnt++;
        }
        iNo=iNo/10;
    }
return i;
}
int main() 
{
    int iValue = 0;
    int iRet =0;
    printf("enter number\n");
    scanf("%d",&iValue);

    iRet=Count(iValue);
    printf("%d",iRet);
    return 0;

}