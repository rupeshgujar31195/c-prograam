#include<stdio.h>
int CountRange(int iNo)
{
    int iCnt=0;
    iCnt=1;
    while(iNo>=iCnt)
    {
        if(iNo>=3)
        {
            iCnt++;
        }
    }
    return iCnt;

}
int main()
{
    int iValue=0;
    int iRet=0;

    printf("enter number\n");
    scanf("%d",&iValue);

    iRet=CountRange(iValue);
    printf("%d",iRet);
    return 0;
}