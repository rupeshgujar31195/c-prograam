//Accept number from user and return difference between summation of even digits and summation of odd digits

#include<stdio.h>

int CountDiff(int iNo)
{
    

}
int main()
{
    int iValue=0;
    int iRet=0;

    printf("Enter number\n");
    scanf("%d",&iValue);

    iRet=CountDiff(iValue);
    printf("%d",iRet);

    return 0;
}