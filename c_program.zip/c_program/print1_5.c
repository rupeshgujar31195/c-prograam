\\display 1 to 5 no
#include<stdio.h>
int main()
{
	printf("1\n");
		printf("2\n");
		printf("3\n");
		printf("4\n");
		printf("5\n");
		

 for(int i=1;i<=5;i++)
 {
printf("%d\n",i);
 }
 return 0;
} 

	