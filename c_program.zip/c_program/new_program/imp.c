
//addition using malloc()
#include<stdio.h>
#include<stdlib.h>  //standard library for malloc()

//int Addition(int *Brr)
int Addition(int Brr[], int iSize)  

{
	int iSum=0,iCnt=0;
	
	for(iCnt=0;iCnt<iSize;iCnt++)           
	{
		iSum=iSum + Brr[iCnt];
	}
	return iSum;
}
int main()
{
	int *Arr= NULL;
	int iCnt=0, iRet=0,iLength=0;
	printf("enter number of elements\n");
	scanf("%d",&iLength);
	
	Arr= (int*)malloc(sizeof(int) * iLength);
	
	printf("Enter number\n");
	
	for(iCnt=0;iCnt<iLength;iCnt++)
	{
		scanf("%d",&Arr[iCnt]);
	}
	iRet=Addition(Arr,iLength); //Addition(100) hold address of first array i.e. arr[0]
	printf("Addition is:%d",iRet);
	
	free(Arr);
	return 0;
}