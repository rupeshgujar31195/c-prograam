#include<stdio.h>
int Display(int iNo)
{
	int iCnt=0;
	char ch='\0';
	for(iCnt=1,ch='A';iCnt<=iNo;iCnt++,ch++)
	{
		printf("%c\n",ch);
	}
	
	
}
int main()
{
	int iValue=0;
	printf("enter number");
	scanf("%d",&iValue);
	Display(iValue);
	return 0;
}