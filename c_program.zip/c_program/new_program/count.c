#include<stdio.h>

int addition(int);
int main()
{
	
int iValue=0, iRet=0;
printf("enter number");
scanf("%d",&iValue);

iRet=addition(iValue);
printf("addition is %d",iRet);
return 0;
}
int addition(int iNo)
{
	
int iCnt=0;
if(iNo==0)
{
	return 1;  //filter
}
if(iNo<0)
{
	iNo= -iNo;   //updator
}

while(iNo>0)
{
	iCnt++;
	iNo=iNo/10;
}
return iCnt;
}
