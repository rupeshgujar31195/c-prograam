#include<stdio.h>
#include<math.h>
 int Power(int,int);
 int main()
 { 
 int iValue1=0,iValue2=0,iRet=0;
 printf("enter 2 number");
 scanf("%d %d",&iValue1,&iValue2);
  
  iRet=Power(iValue1,iValue2);
  printf("result is:%d",iRet);
  return 0;
 }
 int Power(int x,int y)//o(N) where time complecity is y
 
 
 {
	 int iCnt=0,iMult=1;
	 if(x<0)
	 {
		 x = -x;
	 }
	 if(y<0)
	 {y = -y;}
	
	 for(iCnt=1;iCnt<=y;iCnt++)
	 {
		 iMult=iMult*x;
	 }
	 return iMult;
 }