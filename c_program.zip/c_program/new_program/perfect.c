#include<stdio.h>
#include<stdbool.h>
bool Checkperfect(int);
int main()
{
	int iValue=0;
	bool bRet= false;
	printf("enter number");
	scanf("%d",&iValue);
	bRet=Checkperfect(iValue);
	if(bRet==true)
	{
		printf("number is perfect");
	}
	else{
		printf("numberv is not perfect");
	}
	return 0;
}
bool Checkperfect(int iNumber)
{
	int iSum=0 ,iCnt=0;
	if(iNumber<0)
	{
		iNumber= -iNumber;
	}
	for(iCnt=1;iCnt<=(iNumber/2);iCnt++)
	{
		if(iNumber%iCnt==0)
		{
			iSum=iSum+iCnt;
		}
	if(iSum==iNumber)
	{
		return true;
	}
	else{
		return false;
	}
	}