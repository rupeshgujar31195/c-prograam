#include<stdio.h>
//int Addition(int *Brr)
int Addition(int Brr[])
{
	int iSum=0,iCnt=0;
	
	for(iCnt=0;iCnt<5;iCnt++)
	{
		iSum=iSum + Brr[iCnt];
	}
	return iSum;
}
int main()
{
	int Arr[5];
	int iCnt=0, iRet=0;
	
	printf("Enter number\n");
	
	for(iCnt=0;iCnt<5;iCnt++)
	{
		scanf("%d",&Arr[iCnt]);
	}
	iRet=Addition(Arr); //Addition(100) hold address of first array i.e. arr[0]
	printf("Addition is:%d",iRet);
	return 0;
}