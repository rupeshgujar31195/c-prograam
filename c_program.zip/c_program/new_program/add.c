#include<stdio.h>
 int Addition(int);
 
 int main()
 { int iValue=0, iRet=0;
 printf("enter number");
 scanf("%d",&iValue);
 iRet=Addition(iValue);
 
 printf("addition is:%d",iRet);
	 
	return 0;
	
	 
	 
 }
 
 int Addition(int iNo)
 {  int iDigit=0;
 int sum=0;
 
 while(iNo>0)
 {
	 iDigit=iNo%10;
	 sum=sum+iDigit;
	 iNo=iNo/10;
 }
 return sum;
 }	 