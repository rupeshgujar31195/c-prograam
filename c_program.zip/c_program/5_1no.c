#include<stdio.h>
int Display()
{
	
	int i=5;
	for(i;i>=1;i--)
	{
		printf("%d\n",i);
		
	}
	
}
int main()
{
  Display();
  return 0;
}
  
		